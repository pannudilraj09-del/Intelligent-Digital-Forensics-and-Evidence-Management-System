import os, sqlite3, hashlib, secrets
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, abort, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

ROOT=os.path.dirname(os.path.abspath(__file__)); DB=os.path.join(ROOT,"forensics.db"); STORE=os.path.join(ROOT,"evidence_store")
os.makedirs(STORE,exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get("SECRET_KEY","demo-secret-change-before-deployment"); app.config["MAX_CONTENT_LENGTH"]=20*1024*1024
EXT={"txt","pdf","png","jpg","jpeg","docx","csv","log","zip"}
def now(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def db():
    if "db" not in g:
        g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row; g.db.execute("PRAGMA foreign_keys=ON")
    return g.db
@app.teardown_appcontext
def close_db(e=None):
    c=g.pop("db",None)
    if c: c.close()
def init_db():
    c=sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS cases(id INTEGER PRIMARY KEY,name TEXT,description TEXT,owner INTEGER,created TEXT);
    CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY,case_id INTEGER,name TEXT,stored TEXT,sha256 TEXT,uploader TEXT,uploaded TEXT,notes TEXT);
    CREATE TABLE IF NOT EXISTS custody(id INTEGER PRIMARY KEY,evidence_id INTEGER,actor TEXT,action TEXT,details TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,username TEXT,event TEXT,details TEXT,ip TEXT,created TEXT);
    """)
    if not c.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
        c.execute("INSERT INTO users VALUES(NULL,?,?,?,?)",("admin",generate_password_hash("Admin@123"),"Admin",now()))
        c.execute("INSERT INTO users VALUES(NULL,?,?,?,?)",("analyst",generate_password_hash("Analyst@123"),"Analyst",now()))
    c.commit(); c.close()
def user():
    return db().execute("SELECT id,username,role FROM users WHERE id=?",(session.get("uid"),)).fetchone() if session.get("uid") else None
def audit(event,details,username=None):
    u=user(); name=username or (u["username"] if u else request.form.get("username","Unknown"))
    db().execute("INSERT INTO audit(username,event,details,ip,created) VALUES(?,?,?,?,?)",(name,event,details,request.remote_addr,now())); db().commit()
def token():
    if "_csrf" not in session: session["_csrf"]=secrets.token_urlsafe(24)
    return session["_csrf"]
@app.context_processor
def inject(): return {"current_user":user(),"csrf_token":token}
@app.before_request
def check_csrf():
    if request.method=="POST":
        a=request.form.get("_csrf_token",""); z=session.get("_csrf","")
        if not a or not z or not secrets.compare_digest(a,z): abort(400,"Invalid form security token.")
def login_required(f):
    @wraps(f)
    def w(*a,**k):
        if not user(): return redirect(url_for("login"))
        return f(*a,**k)
    return w
def roles(*allowed):
    def d(f):
        @wraps(f)
        @login_required
        def w(*a,**k):
            if user()["role"] not in allowed:
                audit("ACCESS_DENIED",f"Blocked from {request.path}"); flash("Access denied for your role.","danger"); return redirect(url_for("dashboard"))
            return f(*a,**k)
        return w
    return d
def digest(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(65536),b""): h.update(chunk)
    return h.hexdigest()
@app.route("/")
def home(): return redirect(url_for("dashboard") if user() else url_for("login"))
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        name=request.form.get("username","").strip(); u=db().execute("SELECT * FROM users WHERE username=?",(name,)).fetchone()
        if u and check_password_hash(u["password"],request.form.get("password","")):
            session.clear(); session["uid"]=u["id"]; session["_csrf"]=secrets.token_urlsafe(24); audit("LOGIN_SUCCESS","Successful login",name); return redirect(url_for("dashboard"))
        audit("LOGIN_FAILED","Invalid credentials",name or "Unknown"); flash("Invalid username or password.","danger")
    return render_template("login.html")
@app.post("/logout")
@login_required
def logout():
    audit("LOGOUT","Signed out"); session.clear(); return redirect(url_for("login"))
@app.route("/dashboard")
@login_required
def dashboard():
    c=db(); stats=[c.execute("SELECT COUNT(*) FROM cases").fetchone()[0],c.execute("SELECT COUNT(*) FROM evidence").fetchone()[0],c.execute("SELECT COUNT(*) FROM audit").fetchone()[0]]
    logs=c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("dashboard.html",stats=stats,logs=logs)
@app.route("/cases",methods=["GET","POST"])
@login_required
def cases():
    if request.method=="POST":
        n=request.form.get("name","").strip(); d=request.form.get("description","").strip()
        if n and d:
            db().execute("INSERT INTO cases(name,description,owner,created) VALUES(?,?,?,?)",(n,d,user()["id"],now())); db().commit(); audit("CASE_CREATED",n); flash("Case created.","success")
        else: flash("Enter case name and description.","danger")
        return redirect(url_for("cases"))
    rows=db().execute("SELECT cases.*,(SELECT COUNT(*) FROM evidence WHERE case_id=cases.id) count FROM cases ORDER BY id DESC").fetchall()
    return render_template("cases.html",cases=rows)
@app.route("/case/<int:cid>")
@login_required
def case(cid):
    c=db().execute("SELECT * FROM cases WHERE id=?",(cid,)).fetchone()
    if not c: abort(404)
    items=db().execute("SELECT * FROM evidence WHERE case_id=? ORDER BY id DESC",(cid,)).fetchall()
    return render_template("case.html",case=c,items=items)
@app.post("/case/<int:cid>/upload")
@roles("Admin","Analyst")
def upload(cid):
    if not db().execute("SELECT id FROM cases WHERE id=?",(cid,)).fetchone(): abort(404)
    f=request.files.get("file")
    if not f or not f.filename: flash("Choose a file.","danger"); return redirect(url_for("case",cid=cid))
    name=secure_filename(f.filename)
    if "." not in name or name.rsplit(".",1)[1].lower() not in EXT: flash("File type not allowed.","danger"); return redirect(url_for("case",cid=cid))
    stored=secrets.token_hex(12)+"_"+name; path=os.path.join(STORE,stored); f.save(path); sha=digest(path)
    cur=db().execute("INSERT INTO evidence(case_id,name,stored,sha256,uploader,uploaded,notes) VALUES(?,?,?,?,?,?,?)",(cid,name,stored,sha,user()["username"],now(),request.form.get("notes",""))); db().commit()
    db().execute("INSERT INTO custody(evidence_id,actor,action,details,created) VALUES(?,?,?,?,?)",(cur.lastrowid,user()["username"],"UPLOAD",f"File uploaded; SHA-256 captured: {sha}",now())); db().commit()
    audit("EVIDENCE_UPLOADED",f"{name} added to case {cid}"); flash("Evidence saved and SHA-256 calculated.","success"); return redirect(url_for("case",cid=cid))
@app.route("/evidence/<int:eid>")
@login_required
def inspect(eid):
    e=db().execute("SELECT evidence.*,cases.name case_name FROM evidence JOIN cases ON cases.id=evidence.case_id WHERE evidence.id=?",(eid,)).fetchone()
    if not e: abort(404)
    current=digest(os.path.join(STORE,e["stored"])); ok=current==e["sha256"]
    db().execute("INSERT INTO custody(evidence_id,actor,action,details,created) VALUES(?,?,?,?,?)",(eid,user()["username"],"INTEGRITY_CHECK","Hash match" if ok else "HASH MISMATCH",now())); db().commit()
    audit("INTEGRITY_CHECK",f"Evidence {eid}: {'MATCH' if ok else 'MISMATCH'}")
    chain=db().execute("SELECT * FROM custody WHERE evidence_id=? ORDER BY id DESC",(eid,)).fetchall()
    return render_template("evidence.html",e=e,current=current,ok=ok,chain=chain)
@app.route("/evidence/<int:eid>/download")
@login_required
def download(eid):
    e=db().execute("SELECT * FROM evidence WHERE id=?",(eid,)).fetchone()
    if not e: abort(404)
    db().execute("INSERT INTO custody(evidence_id,actor,action,details,created) VALUES(?,?,?,?,?)",(eid,user()["username"],"DOWNLOAD",e["name"],now())); db().commit(); audit("EVIDENCE_DOWNLOADED",e["name"])
    return send_from_directory(STORE,e["stored"],as_attachment=True,download_name=e["name"])
@app.route("/users",methods=["GET","POST"])
@roles("Admin")
def users():
    if request.method=="POST":
        n=request.form.get("username","").strip(); p=request.form.get("password",""); r=request.form.get("role","")
        if len(n)<3 or len(p)<8 or r not in ("Admin","Analyst","Viewer"): flash("Check username, password length and role.","danger")
        else:
            try: db().execute("INSERT INTO users(username,password,role,created) VALUES(?,?,?,?)",(n,generate_password_hash(p),r,now())); db().commit(); audit("USER_CREATED",f"{n} ({r})"); flash("User created.","success")
            except sqlite3.IntegrityError: flash("Username already exists.","danger")
        return redirect(url_for("users"))
    return render_template("users.html",users=db().execute("SELECT * FROM users ORDER BY id").fetchall())
@app.route("/audit")
@roles("Admin")
def audit_page():
    logs=db().execute("SELECT * FROM audit ORDER BY id DESC LIMIT 300").fetchall()
    alerts=db().execute("SELECT username,COUNT(*) total FROM audit WHERE event='LOGIN_FAILED' AND created >= datetime('now','-1 day') GROUP BY username HAVING COUNT(*)>=3").fetchall()
    return render_template("audit.html",logs=logs,alerts=alerts)
@app.errorhandler(400)
def bad(e): return render_template("error.html",code=400,message=getattr(e,"description","Bad request")),400
@app.errorhandler(404)
def missing(e): return render_template("error.html",code=404,message="Requested item not found."),404
@app.errorhandler(413)
def large(e): return render_template("error.html",code=413,message="File exceeds 20 MB limit."),413
if __name__=="__main__": init_db(); app.run(debug=True)
