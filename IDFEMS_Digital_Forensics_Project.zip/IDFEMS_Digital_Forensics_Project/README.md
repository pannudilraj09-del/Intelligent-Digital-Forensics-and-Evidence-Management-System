# IDFEMS – Intelligent Digital Forensics and Evidence Management System

Local academic prototype using Python Flask, SQLite, HTML, CSS and JavaScript.

## Features
- Login with hashed passwords and Admin/Analyst/Viewer roles
- Investigation case creation
- Evidence file upload (20 MB maximum; selected file extensions)
- SHA-256 fingerprint calculation at upload
- Integrity verification by recalculating the hash
- Chain-of-custody events for upload, integrity check and download
- Audit log for login and evidence activity
- Basic alert for 3+ failed logins by one username in the last 24 hours

## Run on Windows
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py app.py
```
Open http://127.0.0.1:5000

## Demo accounts
Admin: `admin` / `Admin@123`
Analyst: `analyst` / `Analyst@123`

Admin can create accounts. Admin and Analyst can upload evidence. Logged-in users can inspect, verify and download evidence.

## Demonstration
1. Sign in as Admin and create a case.
2. Upload a sample text or PDF file.
3. Open the evidence record and show its SHA-256 fingerprint.
4. Show the integrity status and chain-of-custody history.
5. Download the file and view the new custody entry.
6. Open Audit & Alerts as Admin.

## Limitations
Educational prototype only; not a certified forensic acquisition tool. It does not create forensic disk images, preserve all operating-system metadata, digitally sign custody records or provide tamper-proof storage. Use sample, non-sensitive files. For real deployment, configure a strong SECRET_KEY, disable debug mode, use HTTPS and add rate limiting and stronger access controls.
